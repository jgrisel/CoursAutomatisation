Dans le package vous trouverez 3 fichiers :
- un README
- le DIE
- un script d’installation de tomcat et déploiement de jenkins
Sur votre poste vous aurez besoin d’un logiciel permettant le transfert (cygwin).
